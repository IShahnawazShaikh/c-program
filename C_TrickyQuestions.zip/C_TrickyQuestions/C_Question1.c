#include<stdio.h>
void main(){
    
int x=10;
	{
	    int x=5;
        {  
			 {
			    printf("%d,",x);
			    int x=3;            
			 }
		   printf("%d,",x);
		   x=1;    
		 }
		printf("%d,",x);
	}	
printf("%d",x);
}