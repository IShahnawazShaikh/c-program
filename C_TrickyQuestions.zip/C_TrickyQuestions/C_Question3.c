#include<stdio.h>
fun();
void main(){
  int (*p)()=fun;
  (*p)();
  
}
fun(){
    printf("function is executed");
}
