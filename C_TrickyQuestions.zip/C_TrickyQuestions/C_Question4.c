#include<stdio.h>
func();
void main(){
  int i=1;
  switch(i){
	 case 1:
	    int (*p)()=func;
	    (*p)();
	break;
}
func(){
    		 printf("func");  
}


