#include<stdio.h>
void main(){
 
   int i=3,j=3,p;
   i=--i<<(i+1);
   j=(j++<<j);
   p=j>>(j-j)+4;
   printf("%d,%d,%d",i,j,p);
  
}

