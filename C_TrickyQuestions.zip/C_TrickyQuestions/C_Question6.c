#include<stdio.h>
void main(){
 
   int *ptr1,**ptr2,i;

  i=8<<2;
  ptr1=&i;
  ptr2=&ptr1;
  printf("%d,%d",*ptr1,(int)**ptr2);
}

