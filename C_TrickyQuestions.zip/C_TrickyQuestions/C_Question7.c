#include<stdio.h>
void main(){
 
   if(printf("%d,first",printf("%d")))
     printf("hello-3");
	else
       printf("no hello");
	
}

