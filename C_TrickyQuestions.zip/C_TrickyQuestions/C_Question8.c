#include<stdio.h>
void main(){
	int x=1;
 while(1){ 
      if(x=2)
	     printf("%d",x);
    else
       printf("%d",x);
	}
	
}

